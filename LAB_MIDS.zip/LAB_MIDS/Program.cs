﻿using System;
namespace LAB_MIDS
{

    public class StudentClub
    {
        private static string Society;
        private static double budegt;
        private static double fund;
        private static ClubRole president;
        private static ClubRole vicepresident;
        private static ClubRole generalsec;
        private static ClubRole fianancesec;

        public static void setfundSociety(double val) {
            fund = val;
        }
        public static double getfundSociety()
        {
            return fund;
        }
        public static void setRegister(string val)
        {
            Society = val;
        }
        public static string getRegister()
        {
            return Society;
        }

       
    }
    public class Society: StudentClub
    {
        private static string name;
        private static string activity;
        private static double contact;
        private static string events;

        public static void addActivity(string val)
        {
            activity = val;
        }
        public static string listEvents(string val)
        {
            events = val;
            return events;
        }
    }

    public class FundedSociety: Society
    {
        private static double fundingAmount;
    }
    public class NonFundedSociety : Society
    {
        public static void show() { 
            Console.Write("No Funds for Society"); 
        }
        
    }
    public class ClubRole
    {
        private static string name;
        private static string role;
        private static string contactInfo;
    }
    internal class Program
    {
        static void Main(string[] args)
        {

            StudentClub club = new StudentClub();
            do
            {
                Console.Write("Student Club Management System");
                Console.Write("------------------------------");
                Console.Write("1.Register New Society");
                Console.Write("2.Allocate Funding to Societies");
                Console.Write("3.Register Event For Society");
                Console.Write("4.Display Society Funding Information");
                Console.Write("5.Display Events For Society");
                Console.Write("6.Exit");
                Console.Write("Enter Choice: ");
                int choice = Console.Read();
                switch (choice)
                {
                    case 1:

                        Console.Write("Society: ");
                        string set = setRegister("Techbit");

                        break;
                    case 2:

                        Console.Write("Fund: ");
                        double sett = setfundSociety(600.56);

                        break;
                    case 3:

                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    default:
                        Console.Write("Exiting Program");
                        break;




                }
            }
            while (choice != 6);
        }
    }
    }
